import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class paperback extends book {
	String condition;
	double pageCount;

	// COnstructor
	public paperback(int barcode, String type, String title, String language, String genre, String releaseDate, 
			int stockQuantity, double retailPrice, double pageCount, String condition) {
		super(barcode, type, title, language, genre, releaseDate, stockQuantity, retailPrice);
		this.condition = condition;
		this.pageCount = pageCount;
	}

	// Getter and setter methods
	public double getPageCount() {
		return (double) pageCount;
	}

	public void setPageCount(double pageCount) {
		this.pageCount = pageCount;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}
	
	@Override
    public String toString(){
        return (barcode+", "+type+", "+title+", "+language+", "+genre+", "+releaseDate+", "+stockQuantity+
        		", "+retailPrice+", "+pageCount+", "+condition);
    }
	
	
	// method that returns an array of book objects consisting only of paperbacks
	public static book[] viewPaperbacks() throws IOException {
		File inputFile = new File("Stock.txt");
		Scanner fileScanner = new Scanner(inputFile);
		int arrayIndex = 0;
		book[] paperbackArray = new book[10];
		while (fileScanner.hasNextLine()) {
			String[] bookDetails = fileScanner.nextLine().split(",") ;
			if((bookDetails[1].trim()).equals("paperback")) {
				book books = new paperback(Integer.parseInt(bookDetails[0].trim()),(bookDetails[1].trim()),
						(bookDetails[2].trim()),(bookDetails[3].trim()),(bookDetails[4].trim()),
						(bookDetails[5].trim()),Integer.parseInt(bookDetails[6].trim()),
						Double.parseDouble(bookDetails[7].trim()),Double.parseDouble(bookDetails[8].trim()),
						(bookDetails[9].trim()));
				
				paperbackArray[arrayIndex] = books;
				//System.out.println(books);
				arrayIndex++;	
			}else {}
		}
		fileScanner.close();

		//String paperbackStr = (paperbackArray[0]+"\n"+paperbackArray[1]+"\n"+paperbackArray[2]+"\n"+paperbackArray[3]+"\n"+paperbackArray[4]+"\n"+paperbackArray[5]);
		return paperbackArray;
	}
	
	public static void main(String[] args) throws IOException{
		viewPaperbacks();
	}

}
