import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class audiobook extends book{
	private String format;
	private double listeningLength;

	// Constructor
	public audiobook(int barcode, String type, String title, String language, String genre, String releaseDate, int stockQuantity,
			double retailPrice, double listeningLength, String format) {
		super(barcode, type, title, language, genre, releaseDate, stockQuantity, retailPrice);
        this.format = format;
        this.listeningLength = listeningLength;
	}

	// Getter and setter methods
	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public double getListeningLength() {
		return listeningLength;
	}

	public void setListeningLength(double listeningLength) {
		this.listeningLength = listeningLength;
	}
	
    @Override
    public String toString(){
        return (barcode+", "+type+", "+title+", "+language+", "+genre+", "+releaseDate+", "+stockQuantity+
        		", "+retailPrice+", "+listeningLength+", "+format);
    }
    
    
    // method that returs an array of book objects with only audiobooks
	public static book[] viewAudiobooks() throws IOException {
		File inputFile = new File("Stock.txt");
		Scanner fileScanner = new Scanner(inputFile);
		int arrayIndex = 0;
		book[] audioArray = new book[30];
		while (fileScanner.hasNextLine()) {
			String[] bookDetails = fileScanner.nextLine().split(",") ;
			if((bookDetails[1].trim()).equals("audiobook")) {
				book books = new audiobook(Integer.parseInt(bookDetails[0].trim()),(bookDetails[1].trim()),
						(bookDetails[2].trim()),(bookDetails[3].trim()),(bookDetails[4].trim()),
						(bookDetails[5].trim()),Integer.parseInt(bookDetails[6].trim()),
						Double.parseDouble(bookDetails[7].trim()),Double.parseDouble(bookDetails[8].trim()),
						(bookDetails[9].trim()));
				
				audioArray[arrayIndex] = books;
				//System.out.println(books);
				arrayIndex++;	
				
				
			}else {}			
		}
		fileScanner.close();

		
		//String audiobookStr = (audioArray[0]+"\n"+audioArray[1]+"\n"+audioArray[2]+"\n"+audioArray[3]+"\n"+audioArray[4]);
		return audioArray;
		
	}
	
	public static void main(String[] args) throws IOException{
		viewAudiobooks();
	}
	
}
