//Enum for book genre
public enum genre {
	POLITICS, 
	BUSINESS, 
	COMPUTERSCIENCE,
	BIOGRAPHY;
}
