import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class ebook extends book{
	private String format;
	private double pageCount;

	// Constructor
	public ebook(int barcode, String type, String title, String language, String genre, String releaseDate, int stockQuantity,
			double retailPrice, double pageCount, String format) {
		super(barcode, type, title, language, genre, releaseDate, stockQuantity, retailPrice);
		this.format = format;
		this.pageCount = pageCount;
	}

	//Getter and setter methods
	public double getPageCount() {
		return pageCount;
	}

	public void setPageCount(double pageCount) {
		this.pageCount = pageCount;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}
	
	@Override
    public String toString(){
        return (barcode+", "+type+", "+title+", "+language+", "+genre+", "+releaseDate+", "+stockQuantity+
        		", "+retailPrice+", "+pageCount+", "+format);
    }
	
	// Method that returns an array of book objects consisting only of ebooks
	public static book[] viewEbooks() throws IOException {
		File inputFile = new File("Stock.txt");
		Scanner fileScanner = new Scanner(inputFile);
		int arrayIndex = 0;
		book[] ebookArray = new book[30];
		while (fileScanner.hasNextLine()) {
			String[] bookDetails = fileScanner.nextLine().split(",") ;
			if((bookDetails[1].trim()).equals("ebook")) {
				book books = new ebook(Integer.parseInt(bookDetails[0].trim()),(bookDetails[1].trim()),
						(bookDetails[2].trim()),(bookDetails[3].trim()),(bookDetails[4].trim()),
						(bookDetails[5].trim()),Integer.parseInt(bookDetails[6].trim()),
						Double.parseDouble(bookDetails[7].trim()), Double.parseDouble(bookDetails[8].trim()),
						(bookDetails[9].trim()));
				
				ebookArray[arrayIndex] = books;
				//System.out.println(books);
				arrayIndex++;	
			}else {}
		}
		fileScanner.close();
		
		//String ebookStr = (ebookArray[0]+"\n"+ebookArray[1]+"\n"+ebookArray[2]+"\n"+ebookArray[3]);
		
		return ebookArray;
	}
	
	public static void main(String[] args) throws IOException{
		viewEbooks();
	}

}
