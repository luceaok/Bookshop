//Enum for paperbook condition
public enum condition {
	NEW,
	USED
}
