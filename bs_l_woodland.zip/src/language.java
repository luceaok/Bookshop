// Enum for language of book
public enum language {
	 ENGLISH,
	 FRENCH;
}
