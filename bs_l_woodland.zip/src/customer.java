import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

public class customer extends user{
	private double credit;
	private basket basket;

    // Constructor
    public customer(int userId, String username, String surname, int houseNo, String postcode, String city, 
    		double initialCredit, String userType) {
        super(userId, username, surname, houseNo, postcode, city, userType); 
        this.credit = initialCredit;
        this.setBasket(new basket());
        
    }
    
    @Override
    public String toString(){
        return (userId+", "+username+", "+surname+", "+houseNo+", "+postcode+", "+city+", "+credit+", "+userType);
    }
    
    
    // Reads the UserAccounts text file and extracts the information on the customers and adds it to an array of customer objects called customerArray
    public static customer[] customerInfo() throws IOException {
	    File inputFile = new File("UserAccounts.txt");
		Scanner fileScanner = new Scanner(inputFile);
		int arrayIndex = 0;
		customer[] customerArray = new customer[3];
		while (fileScanner.hasNextLine()) {
			String[] fields = fileScanner.nextLine().split(",") ;
			if((fields[7].trim()).equals("customer")) {
				customer customer = new customer(Integer.parseInt(fields[0].trim()), 
						fields[1].trim(),
						fields[2].trim(),
						Integer.parseInt(fields[3].trim()),
						fields[4].trim(),
						fields[5].trim(),
						Double.parseDouble(fields[6].trim()),
						fields[7].trim());
				
				
				
				customerArray[arrayIndex] = customer;
				arrayIndex++;			
			}else {}
		}
		
		fileScanner.close();
		
		return customerArray;
		
	}
    
    // Procedure that is supposed to update the credits of the user in the text file after they make a purchase by searching for matching credit amount in the text file
    // could lead to issues if two users have the same credit amount
    public void updateCredit(double credit, double newCredit) throws IOException {
    	System.out.print(String.valueOf(credit));
    	File inputFile = new File("UserAccounts.txt");
    	Scanner fileScanner = new Scanner(inputFile);
    	int rowIndex = 0;
    	
    	while(fileScanner.hasNextLine()) {
    		String line = fileScanner.nextLine();
    		String[] parts = line.split(",");
    		if(parts[0].trim().equals(String.valueOf(credit))) {
    			break;
    		}else {
    			rowIndex++;
    		}
    	}
    	fileScanner.close();
    	
    	Path path = Paths.get("UserAccounts.txt");
    	List<String> rows = Files.readAllLines(path, StandardCharsets.UTF_8);
    	
    	String lineToUpdate = rows.get(rowIndex);
    	String[] parts = lineToUpdate.split(",");
    	
    	if(parts[0].trim().equals(String.valueOf(credit))) {
    		double oldCreds = Double.parseDouble(parts[6].trim());
    		double newCreds = newCredit;
    		parts[6] = " "+String.valueOf(newCredit);
    		
    		String updatedLine = String.join(",", parts);
    		rows.set(rowIndex, updatedLine);
    		
    		Files.write(path, rows, StandardCharsets.UTF_8);
    	}
    }
    
    
    public static void main(String[] args) throws IOException{

	}
    
    // getter and setter methods
    
    public String getUsername() {
    	return username;
    }
    
    // concatenates the address
    public String getAddress() {
    	String address = houseNo+", "+city+", "+postcode;
    	return address;
    }

	public basket getBasket() {
		return basket;
	}

	public void setBasket(basket basket) {
		this.basket = basket;
	}
	
	public void setCredit() {
		this.credit = credit;
	}
	
	public double getCredit() {
		return credit;
	}
	

}
