import java.awt.EventQueue;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.awt.Color;

public class adminFrame extends JFrame {

    private static final String STOCK_FILE_PATH = "Stock.txt";
	private JPanel admin_pane;
	private JTextField titleField;
	public JTextField barcodeField;
	private JTextField dateField;
	private JTextField priceField;
	public String type;
	private JTextField pageField;

	/**
	 * Launch the application.
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		viewBookList();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					adminFrame frame = new adminFrame(); //create new frame
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws IOException 
	 */
	public adminFrame() throws IOException {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 727, 521);
		admin_pane = new JPanel();
		admin_pane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		//making the admin pane and adding tabs

		setContentPane(admin_pane);
		admin_pane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 34, 695, 441);
		admin_pane.add(tabbedPane);
		
		JPanel viewPanel = new JPanel();
		tabbedPane.addTab("View Books", null, viewPanel, null);
		viewPanel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(30, 36, 257, 366);
		viewPanel.add(scrollPane);
		
		//creating a JTextArea that holds all the books in the text file when you log in
		JTextArea txtrHere = new JTextArea();
		txtrHere.setEditable(false);
		
		try {
		    ArrayList<book> bookList = viewBookList();
		    StringBuilder sb = new StringBuilder();

		    
	    	
    		for (book book : bookList) {
    		
		        sb.append("Title: ").append(book.getTitle()).append("\n");
		        sb.append("Barcode: ").append(book.getBarcode()).append("\n");
		        sb.append("Genre: ").append(book.getGenre()).append("\n");
		        sb.append("Price: £").append(book.getRetailPrice()).append("\n");
		        sb.append("Quantity: ").append(book.getQuantity()).append("\n");
		        sb.append("Language: ").append(book.getLanguage()).append("\n");
		        sb.append("Type: ").append(book.getType()).append("\n");
		        if (book.getType().equals("paperback")) {
		        	paperback paperback = (paperback) book;
			        sb.append("Condition: ").append(paperback.getCondition()).append("\n");
			        sb.append("Pages: ").append(paperback.getPageCount()).append("\n");
			        sb.append("\n");
    			}
    	
    			if (book.getType().equals("audiobook")) {
    				audiobook audiobook = (audiobook) book;
			        sb.append("Format: ").append(audiobook.getFormat()).append("\n");
			        sb.append("Length: ").append(audiobook.getListeningLength()).append("\n");
			        sb.append("\n");
    			}
    			
			    if (book.getType().equals("ebook")) {
			    	ebook ebook = (ebook) book;
			        sb.append("Format: ").append(ebook.getFormat()).append("\n");
			        sb.append("Pages: ").append(ebook.getPageCount()).append("\n");
			        sb.append("\n");
				  }
    		}
		    //all books were appended to a stringBuilder so they can now be added to the JTextArea
		    txtrHere.setText(sb.toString());
		} catch (IOException e) {
		    // Handle the exception appropriately
		}

		scrollPane.setViewportView(txtrHere);
		
		JLabel lblNewLabel_7 = new JLabel("All Books:");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_7.setBounds(30, 11, 257, 14);
		viewPanel.add(lblNewLabel_7);
		
		//for the add new book tab we create labels and text fields
	
		JPanel newPanel = new JPanel();
		tabbedPane.addTab("New Book", null, newPanel, null);
		newPanel.setLayout(null);
		
		titleField = new JTextField();
		titleField.setBounds(147, 107, 96, 20);
		newPanel.add(titleField);
		titleField.setColumns(10);
		
		barcodeField = new JTextField();
		barcodeField.setBounds(147, 138, 96, 20);
		newPanel.add(barcodeField);
		barcodeField.setColumns(10);
		
		dateField = new JTextField();
		dateField.setBounds(492, 107, 96, 20);
		newPanel.add(dateField);
		dateField.setColumns(10);
		
		priceField = new JTextField();
		priceField.setBounds(492, 138, 96, 20);
		newPanel.add(priceField);
		priceField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Title:");
		lblNewLabel_1.setBounds(49, 107, 91, 14);
		newPanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Barcode:");
		lblNewLabel_2.setBounds(49, 138, 91, 14);
		newPanel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Language:");
		lblNewLabel_3.setBounds(49, 169, 91, 14);
		newPanel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Genre:");
		lblNewLabel_4.setBounds(49, 200, 91, 14);
		newPanel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Release Date:");
		lblNewLabel_5.setBounds(380, 107, 127, 14);
		newPanel.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Retail Price:");
		lblNewLabel_6.setBounds(380, 138, 127, 14);
		newPanel.add(lblNewLabel_6);
		
		JLabel pageLabel = new JLabel("Number of Pages:");
		pageLabel.setBounds(380, 169, 127, 14);
		newPanel.add(pageLabel);
		
		JLabel conditionLabel = new JLabel("Condition:");
		conditionLabel.setBounds(380, 200, 127, 14);
		newPanel.add(conditionLabel);
		
		//comboBoxes using enums dependent of the type of book the admin wants to add
		
		JComboBox genreBox = new JComboBox();
		genreBox.setModel(new DefaultComboBoxModel(genre.values()));
		genreBox.setBounds(147, 200, 96, 20);
		newPanel.add(genreBox);
		
		JComboBox langBox = new JComboBox();
		langBox.setModel(new DefaultComboBoxModel(language.values()));
		langBox.setBounds(147, 169, 96, 20);
		newPanel.add(langBox);
		
		JComboBox conditionBox = new JComboBox();
		conditionBox.setBounds(492, 200, 96, 20);
		newPanel.add(conditionBox);
		
		JRadioButton paperbackRadioButton = new JRadioButton("Paperback");
		paperbackRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pageLabel.setText("Number of Pages:");
				conditionLabel.setText("Condition:");
				conditionBox.setModel(new DefaultComboBoxModel(condition.values()));
			}
		});
		paperbackRadioButton.setBounds(89, 42, 109, 23);
		newPanel.add(paperbackRadioButton);
		
		JRadioButton audioRadioButton = new JRadioButton("Audiobook");
		audioRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pageLabel.setText("Listening Length:");
				conditionLabel.setText("Format:");
				conditionBox.setModel(new DefaultComboBoxModel(audioFormat.values()));
			}
		});
		audioRadioButton.setBounds(278, 42, 109, 23);
		newPanel.add(audioRadioButton);
		
		JRadioButton eRadioButton = new JRadioButton("EBook");
		eRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pageLabel.setText("Number of Pages:");
				conditionLabel.setText("Format:");
				conditionBox.setModel(new DefaultComboBoxModel(ebookFormat.values()));
			}
		});
		
		eRadioButton.setBounds(479, 42, 109, 23);
		newPanel.add(eRadioButton);
		
		//create a button group so only one radiobutton can be selected		
		ButtonGroup group = new ButtonGroup();
		group.add(eRadioButton);
		group.add(audioRadioButton);
		group.add(paperbackRadioButton);
		
		//errors produced in labels to the admin can see which inputs were invalid
		JLabel barcodeError = new JLabel("Incorrect Input");
		barcodeError.setForeground(new Color(255, 0, 0));
		barcodeError.setBounds(258, 141, 112, 14);
		barcodeError.setVisible(false);
		newPanel.add(barcodeError);
		
		JLabel priceError = new JLabel("Incorrect Input");
		priceError.setForeground(new Color(255, 0, 0));
		priceError.setHorizontalAlignment(SwingConstants.LEFT);
		priceError.setBounds(598, 141, 92, 14);
		priceError.setVisible(false);
		newPanel.add(priceError);
		
		JLabel pageError = new JLabel("Incorrect Input");
		pageError.setHorizontalAlignment(SwingConstants.LEFT);
		pageError.setForeground(Color.RED);
		pageError.setBounds(598, 169, 92, 14);
		pageError.setVisible(false);
		newPanel.add(pageError);
		
		JLabel dateError = new JLabel("Incorrect Input");
		dateError.setHorizontalAlignment(SwingConstants.LEFT);
		dateError.setForeground(Color.RED);
		dateError.setBounds(598, 110, 92, 14);
		dateError.setVisible(false);
		newPanel.add(dateError);
		
		JButton addButton = new JButton("Add");
		addButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				paperbackRadioButton.setActionCommand("1");
				audioRadioButton.setActionCommand("2");
				eRadioButton.setActionCommand("3");
				
				//validation of book entry
				String barcodeInput = barcodeField.getText();
				if (!(barcodeInput.length() == 8 && barcodeInput.matches("[0-9]+"))) {
					barcodeError.setVisible(true);
				}else {
					barcodeError.setVisible(false);
				}
				
				if (!(isValidDateFormat(dateField.getText()))) {
					dateError.setVisible(true);
				}else {
					dateError.setVisible(false);
				}
				try {
		            double number1 = Double.parseDouble(priceField.getText());
		            priceError.setVisible(false);
		        } catch (NumberFormatException e1) {
		        	priceError.setVisible(true);
		        }
				
				try {
		            double number2 = Double.parseDouble(pageField.getText());
		            pageError.setVisible(false);
		        } catch (NumberFormatException e1) {
		        	pageError.setVisible(true);
		        }

				if(group.getSelection() == null) {
					JOptionPane.showMessageDialog(null, "You must select the book type!", "Error", JOptionPane.ERROR_MESSAGE);
				}else {
					if(group.getSelection().getActionCommand()=="1") {
						type = "paperback";
					}
					if(group.getSelection().getActionCommand()=="2") {
						type = "audiobook";
					}
					if(group.getSelection().getActionCommand()=="3") {
						type = "ebook";
					}
				}
				
				//creating the new book and adding it to the text file
				if(type == "paperback") {
					book books = new paperback(Integer.parseInt(barcodeField.getText()),
							(type),
							(titleField.getText()),
							(langBox.getSelectedItem().toString()),
							(genreBox.getSelectedItem().toString()),
							(dateField.getText()),
							1,
							Double.parseDouble(priceField.getText()),
							Double.parseDouble(pageField.getText()),
							(conditionBox.getSelectedItem()).toString()
							);
					System.out.println(books);
					try {
						newBook(books, Integer.parseInt(barcodeField.getText()));
					} catch (NumberFormatException | IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
					else if(type == "audiobook") {
						book books = new audiobook(Integer.parseInt(barcodeField.getText()),
								(type),
								(titleField.getText()),
								(langBox.getSelectedItem().toString()),
								(genreBox.getSelectedItem().toString()),
								(dateField.getText()),
								1,
								Double.parseDouble(priceField.getText()),
								Double.parseDouble(pageField.getText()),
								(conditionBox.getSelectedItem().toString()));
						System.out.println(books);
						try {
							newBook(books, Integer.parseInt(barcodeField.getText()));
						} catch (NumberFormatException | IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}

				}
					else if(type == "ebook") {
						book books = new ebook(Integer.parseInt(barcodeField.getText()),
								(type),
								(titleField.getText()),
								(langBox.getSelectedItem().toString()),
								(genreBox.getSelectedItem().toString()),
								(dateField.getText()),
								1,
								Double.parseDouble(priceField.getText()),
								Double.parseDouble(pageField.getText()),
								(conditionBox.getSelectedItem().toString()));
						System.out.println(books);
						try {
							newBook(books, Integer.parseInt(barcodeField.getText()));
						} catch (NumberFormatException | IOException e1) {
							e1.printStackTrace();
						}
						
				}
			}
		});
		
	
		addButton.setBounds(278, 282, 89, 23);
		newPanel.add(addButton);
		
		pageField = new JTextField();
		pageField.setColumns(10);
		pageField.setBounds(492, 166, 96, 20);
		newPanel.add(pageField);
		
		
		
		JLabel lblNewLabel = new JLabel("Bookshop");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setBounds(276, 11, 108, 23);
		admin_pane.add(lblNewLabel);
		
		//sign out takes you back to the log in frame
		JButton btnNewButton = new JButton("Sign Out");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loginFrame loginFrame = new loginFrame();
				loginFrame.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(587, 13, 118, 23);
		admin_pane.add(btnNewButton);
	}
	

   /**  
	* @throws FileNotFoundException 
	* @throws IOException 
	*/
//public procedure that adds a new book based on if the barcode exists in the text file already
    public void newBook(book book, int barcode) throws FileNotFoundException, IOException {
        // Check if the book's barcode is already present in the file
        if (find(barcode)) {
            System.out.println("Barcode already exists in the stock.");
            return;
        }

        try {
            // Open the file in append mode
            BufferedWriter writer = new BufferedWriter(new FileWriter(STOCK_FILE_PATH, true));

            // Write the book's barcode to the file
            writer.write(System.lineSeparator());// Add a new line separator
            writer.write(book.toString());

            // Close the writer
            writer.close();

            System.out.println("Book added to the stock.");
        } catch (IOException e) {
            System.out.println("Error occurred while writing to the stock file: " + e.getMessage());
        }
    }

    private boolean barcodeExists(int i) {
        try {
            // Open the file for reading
            BufferedReader reader = new BufferedReader(new FileReader(STOCK_FILE_PATH));

            String line;

            // Read each line from the file
            while ((line = reader.readLine()) != null) {
                // Check if the barcode exists in the file
                if (line.equals(i)) {
                    reader.close();
                    return true;
                }
            }

            reader.close();
        } catch (IOException e) {
            System.out.println("Error occurred while reading the stock file: " + e.getMessage());
        }

        return false;
    }
    
    /**  
   	* @throws FileNotFoundException 
   	* @throws IOException 
   	*/
    
    //function that finds the barcode in the text file
    private boolean find(int i) throws FileNotFoundException, IOException {
    	
    	int targetBarcode = i;
    	boolean barcodeFound = false;
    	
    	try (BufferedReader br = new BufferedReader(new FileReader("Stock.txt"))) {
            String line;
            barcodeFound = false;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(","); // Split the line based on a delimiter (e.g., comma)

                for (String part : parts) {
                    int barcode;
                    try {
                        barcode = Integer.parseInt(part.trim()); // Assuming each part contains a single integer barcode
                    } catch (NumberFormatException e) {
                        continue; // Skip non-integer parts
                    }

                    if (barcode == targetBarcode) {
                        barcodeFound = true;
                        break;
                    }
                }

                if (barcodeFound) {
                    break;
                }
            }

            if (barcodeFound) {
                System.out.println("Barcode found!");
            } else {
                System.out.println("Barcode not found!");
            }
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
		return barcodeFound;
		
    }
	
    // Creates a sorted arraylist of all books
	public static ArrayList<book> viewBookList() throws IOException{
		
	    ArrayList<book> list = new ArrayList<book>();
	    File inputFile = new File("Stock.txt");
		Scanner fileScanner = new Scanner(inputFile);
		while (fileScanner.hasNextLine()) {
			String[] bookDetails = fileScanner.nextLine().split(",") ;
			// different types of books have different instantiations 
			if((bookDetails[1].trim()).equals("paperback")) {
				list.add(new paperback(Integer.parseInt(bookDetails[0].trim()),(bookDetails[1].trim()),
						(bookDetails[2].trim()),(bookDetails[3].trim()),(bookDetails[4].trim()),
						(bookDetails[5].trim()),Integer.parseInt(bookDetails[6].trim()),
						Double.parseDouble(bookDetails[7].trim()),Double.parseDouble(bookDetails[8].trim()),
						(bookDetails[9].trim())));
			}
			if((bookDetails[1].trim()).equals("audiobook")) {
				list.add(new audiobook(Integer.parseInt(bookDetails[0].trim()),(bookDetails[1].trim()),
						(bookDetails[2].trim()),(bookDetails[3].trim()),(bookDetails[4].trim()),
						(bookDetails[5].trim()),Integer.parseInt(bookDetails[6].trim()),
						Double.parseDouble(bookDetails[7].trim()),Double.parseDouble(bookDetails[8].trim()),
						(bookDetails[9].trim())));
			}
			if((bookDetails[1].trim()).equals("ebook")) {
				list.add(new ebook(Integer.parseInt(bookDetails[0].trim()),(bookDetails[1].trim()),
						(bookDetails[2].trim()),(bookDetails[3].trim()),(bookDetails[4].trim()),
						(bookDetails[5].trim()),Integer.parseInt(bookDetails[6].trim()),
						Double.parseDouble(bookDetails[7].trim()),Double.parseDouble(bookDetails[8].trim()),
						(bookDetails[9].trim())));
			}
		}
		fileScanner.close();
		// Sorting the list based on quantity for the admin
	    Collections.sort(list, Comparator.comparing(book :: getQuantity));
		return list;
	}
	
	// Checks input for date for the new book is a valid date in the right format
	public static boolean isValidDateFormat(String input) {
        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        dateFormat.setLenient(false);

        try {
            dateFormat.parse(input);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }
}
