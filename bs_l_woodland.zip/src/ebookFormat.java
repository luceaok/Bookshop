//Enum for ebook format
public enum ebookFormat {
	EPUB,
	MOBI,
	PDF
}
