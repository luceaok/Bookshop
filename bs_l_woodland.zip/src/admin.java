import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class admin extends user{
	
	// Constructor
	public admin(int userId, String username, String surname, int houseNo, String postcode, String city, String userType) {
		super(userId, username, surname, houseNo, postcode, city, userType);
	}
	
	
	@Override
    public String toString(){
        return (userId+", "+username+", "+surname+", "+houseNo+", "+postcode+", "+city+", "+userType);
    }
    
	// method that reads userAccounts text file and produces object array holding the object admin since there is only 1
    public static admin[] adminInfo() throws IOException {
	    File inputFile = new File("UserAccounts.txt");
		Scanner fileScanner = new Scanner(inputFile);
		int arrayIndex = 0;
		admin[] adminArray = new admin[1];
		while (fileScanner.hasNextLine()) {
			String[] fields = fileScanner.nextLine().split(",") ;
			if((fields[7].trim()).equals("admin")) {
				admin admin = new admin(Integer.parseInt(fields[0].trim()), 
						fields[1].trim(),
						fields[2].trim(),
						Integer.parseInt(fields[3].trim()),
						fields[4].trim(),
						fields[5].trim(),
						fields[7].trim());
				
				
				adminArray[arrayIndex] = admin;
				arrayIndex++;			
			}else {}
		}
		
		fileScanner.close();
		
		System.out.println(adminArray[0]);
		
		return adminArray;
		
	}
    
    public static void main(String[] args) throws IOException{
    	adminInfo();
	}
	
	
	public void newBook() throws IOException {
		
	}

}
