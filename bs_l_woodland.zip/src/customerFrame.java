import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTable;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.JTextPane;
import java.awt.event.ContainerAdapter;
import java.awt.event.ContainerEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

public class customerFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel customer_pane;
	private JTextField searchField;
	private JTable table;
	private JTextField txtCreds;
	private JTextField txtTotal;
	private JTextField filterField;

	/**
	 * Launch the application.
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					customerFrame frame = new customerFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param loggedIn 
	 * @throws IOException 
	 */
	public customerFrame(String loggedIn) throws IOException {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 742, 514);
		customer_pane = new JPanel();
		customer_pane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(customer_pane);
		customer_pane.setLayout(null);
        
		// Creating tabs for the customer pane: Home, Basket and Books
		JTabbedPane customer_tabs = new JTabbedPane(JTabbedPane.TOP);
		customer_tabs.setBounds(10, 36, 695, 432);
		customer_pane.add(customer_tabs);
		
		JPanel home_panel = new JPanel();
		customer_tabs.addTab("Home", null, home_panel, null);
		home_panel.setLayout(null);
	
		
		searchField = new JTextField();
		searchField.setBounds(20, 73, 540, 20);
		home_panel.add(searchField);
		searchField.setColumns(10);
		
		String loggedInUser = loggedIn;
        customer[] customerArray = customer.customerInfo();
    	customer user2 = customerArray[0];
    	customer user3 = customerArray[1];
    	customer user4 = customerArray[2]; 
    	//Set the users as customers so we can access information like credit amount
        
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(20, 104, 646, 160);
		home_panel.add(scrollPane_3);
		
		table = new JTable();		
		book[] paperbacks = paperback.viewPaperbacks();
		book[] audiobooks = audiobook.viewAudiobooks();
		book[] ebooks = ebook.viewEbooks();
		//table created with all known books in text file
		// I was unable to add to the table dynamically so this was a last resort
		// Unfortunately new books will not be seen here
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"paperback", paperbacks[0].barcode, paperbacks[0].title, paperbacks[0].language, paperbacks[0].genre, paperbacks[0].releaseDate, paperbacks[0].stockQuantity, paperbacks[0].retailPrice},
				{"paperback",paperbacks[1].barcode, paperbacks[1].title, paperbacks[1].language, paperbacks[1].genre, paperbacks[1].releaseDate, paperbacks[1].stockQuantity, paperbacks[1].retailPrice},
				{"paperback",paperbacks[2].barcode, paperbacks[2].title, paperbacks[2].language, paperbacks[2].genre, paperbacks[2].releaseDate, paperbacks[2].stockQuantity, paperbacks[2].retailPrice},
				{"paperback",paperbacks[3].barcode, paperbacks[3].title, paperbacks[3].language, paperbacks[3].genre, paperbacks[3].releaseDate, paperbacks[3].stockQuantity, paperbacks[3].retailPrice},
				{"paperback",paperbacks[4].barcode, paperbacks[4].title, paperbacks[4].language, paperbacks[4].genre, paperbacks[4].releaseDate, paperbacks[4].stockQuantity, paperbacks[4].retailPrice},
				{"paperback",paperbacks[5].barcode, paperbacks[5].title, paperbacks[5].language, paperbacks[5].genre, paperbacks[5].releaseDate, paperbacks[5].stockQuantity, paperbacks[5].retailPrice},
				{"audiobook",audiobooks[0].barcode, audiobooks[0].title, audiobooks[0].language, audiobooks[0].genre, audiobooks[0].releaseDate, audiobooks[0].stockQuantity, audiobooks[0].retailPrice},
				{"audiobook",audiobooks[1].barcode, audiobooks[1].title, audiobooks[1].language, audiobooks[1].genre, audiobooks[1].releaseDate, audiobooks[1].stockQuantity, audiobooks[1].retailPrice},
				{"audiobook",audiobooks[2].barcode, audiobooks[2].title, audiobooks[2].language, audiobooks[2].genre, audiobooks[2].releaseDate, audiobooks[2].stockQuantity, audiobooks[2].retailPrice},
				{"audiobook",audiobooks[3].barcode, audiobooks[3].title, audiobooks[3].language, audiobooks[3].genre, audiobooks[3].releaseDate, audiobooks[3].stockQuantity, audiobooks[3].retailPrice},
				{"audiobook",audiobooks[4].barcode, audiobooks[4].title, audiobooks[4].language, audiobooks[4].genre, audiobooks[4].releaseDate, audiobooks[4].stockQuantity, audiobooks[4].retailPrice},
				{"ebook",ebooks[0].barcode, ebooks[0].title, ebooks[0].language, ebooks[0].genre, ebooks[0].releaseDate, ebooks[0].stockQuantity, ebooks[0].retailPrice},
				{"ebook",ebooks[1].barcode, ebooks[1].title, ebooks[1].language, ebooks[1].genre, ebooks[1].releaseDate, ebooks[1].stockQuantity, ebooks[1].retailPrice},
				{"ebook",ebooks[2].barcode, ebooks[2].title, ebooks[2].language, ebooks[2].genre, ebooks[2].releaseDate, ebooks[2].stockQuantity, ebooks[2].retailPrice},
				{"ebook",ebooks[3].barcode, ebooks[3].title, ebooks[3].language, ebooks[3].genre, ebooks[3].releaseDate, ebooks[3].stockQuantity, ebooks[3].retailPrice},
			},
			new String[] {
				"Type", "Barcode", "Title", "Language", "Genre", "Release Date", "Quantity ", "Price"
			}
		));
		scrollPane_3.setViewportView(table);
		
		// Searching for barcode in the table and if found selects the table row, otherwise an error label is produced
		JLabel searchError = new JLabel("Item Not Found");
		searchError.setHorizontalAlignment(SwingConstants.CENTER);
		searchError.setForeground(new Color(255, 0, 0));
		searchError.setBounds(285, 309, 131, 14);
		home_panel.add(searchError);
		searchError.setVisible(false);
		
		JButton searchButton = new JButton("Search");
		searchButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String searchText = searchField.getText();
		        boolean found = false;

		        // Iterate over the table's rows and columns to search for the item
		        int column = 1;
		        for (int row = 0; row < table.getRowCount(); row++) {
		        	Object value = table.getValueAt(row, column);
	                if (value != null && value.toString().contains(searchText)) {
	                    table.changeSelection(row, column, false, false);
	                    found = true;
	                    break;
	                }
	                if (found) {
		                break;
		            }
		        }

		        // Update the result label
		        if (found) {
		        	searchError.setVisible(false);
		        } else {
		        	searchError.setVisible(true);
		        }
		    }
		});
		searchButton.setBounds(573, 72, 89, 23);
		home_panel.add(searchButton);
		
		JLabel successAdd = new JLabel("Added to Basket!");
		successAdd.setForeground(new Color(0, 128, 64));
		successAdd.setHorizontalAlignment(SwingConstants.CENTER);
		successAdd.setBounds(285, 309, 131, 14);
		home_panel.add(successAdd);
		successAdd.setVisible(false);
		
		JPanel basket_panel = new JPanel();
		customer_tabs.addTab("Basket", null, basket_panel, null);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(64, 52, 264, 251);
		basket_panel.add(scrollPane_4);
		
		JLabel lblTotalToPay = new JLabel("Total To Pay:");
		lblTotalToPay.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTotalToPay.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTotalToPay.setBounds(501, 141, 112, 14);
		basket_panel.add(lblTotalToPay);
		
		txtTotal = new JTextField();
		txtTotal.setHorizontalAlignment(SwingConstants.CENTER);
		txtTotal.setEditable(false);
		txtTotal.setText("£0"); // Initally basket is empty
		txtTotal.setBounds(441, 161, 172, 50);
		basket_panel.add(txtTotal);
		txtTotal.setColumns(10);
		
		JTextArea basketarea = new JTextArea();
		
		basket basket = new basket();
		
		StringBuilder itemsInBasket = basket.displayBasketItems();
		basketarea.setText(itemsInBasket.toString());
		scrollPane_4.setViewportView(basketarea);
		
		JButton addtobasket = new JButton("Add To Basket");
		addtobasket.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int column = 1;
				int row = table.getSelectedRow();
				String value = table.getModel().getValueAt(row, column).toString();
				int barcode = Integer.parseInt(value); // Barcode selected from table row
				double total = 0;

		        if (loggedInUser.equals("user2")) {
		        	System.out.print(user2.getUsername());
					basket.addToBasket(barcode); // Book added to basket using basket method addToBasket that takes barcode
		            StringBuilder itemsInBasket; //Initialising a stringBuilder that the basket items will be appended to
					try {
						itemsInBasket = basket.displayBasketItems();
						System.out.print(itemsInBasket);
						basketarea.setText(itemsInBasket.toString());
						total = basket.getTotal(); //getTotal adds the prices of all books in the basket
						txtTotal.setText("£"+String.valueOf(total));
						
					} catch (IOException e2) {
						e2.printStackTrace();
					}
					
		            successAdd.setVisible(true);
		            Timer timer = new Timer(2000, e1 -> successAdd.setVisible(false)); //Success label is only visible for 2 seconds
		            timer.setRepeats(false); // Only run the timer once
		            timer.start();
		        }
		        if (loggedInUser.equals("user3")) {
		        	System.out.print(user3.getUsername());
					basket.addToBasket(barcode);
		            StringBuilder itemsInBasket;
					try {
						itemsInBasket = basket.displayBasketItems();
						System.out.print(itemsInBasket);
						basketarea.setText(itemsInBasket.toString());
						total = basket.getTotal();
						txtTotal.setText("£"+String.valueOf(total));
					} catch (IOException e2) {
						e2.printStackTrace();
					}
					
		            successAdd.setVisible(true);
		            Timer timer = new Timer(2000, e1 -> successAdd.setVisible(false));
		            timer.setRepeats(false); // Only run the timer once
		            timer.start();
		        }
		        if (loggedInUser.equals("user4")) {
		        	System.out.print(user4.getUsername());
					basket.addToBasket(barcode);
		            StringBuilder itemsInBasket;
					try {
						itemsInBasket = basket.displayBasketItems();
						System.out.print(itemsInBasket);
						basketarea.setText(itemsInBasket.toString());
						total = basket.getTotal();
						txtTotal.setText("£"+String.valueOf(total));
					} catch (IOException e2) {
						e2.printStackTrace();
					}
		            successAdd.setVisible(true);
		            Timer timer = new Timer(2000, e1 -> successAdd.setVisible(false));
		            timer.setRepeats(false); // Only run the timer once
		            timer.start();
		        }
			}
		});
		addtobasket.setBounds(275, 275, 141, 23);
		home_panel.add(addtobasket);
		
		filterField = new JTextField();
		filterField.setColumns(10);
		filterField.setBounds(138, 35, 225, 20);
		home_panel.add(filterField);
		
		JButton goButton = new JButton("Go"); // Go button does nothing
		goButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                int filterHours = Integer.parseInt(filterField.getText()); // Filter functionality that does not work
	        }
	    });
		goButton.setBounds(471, 34, 89, 23);
		home_panel.add(goButton);
		
		JLabel lblNewLabel = new JLabel("Audiobooks Over");
		lblNewLabel.setBounds(20, 38, 116, 14);
		home_panel.add(lblNewLabel);
		
		JLabel lblHours = new JLabel("Hours");
		lblHours.setBounds(373, 38, 116, 14);
		home_panel.add(lblHours);
		
		
		JPanel books_panel = new JPanel();
		customer_tabs.addTab("Books", null, books_panel, null);
		books_panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(75, 32, 545, 361);
		books_panel.add(scrollPane);
		
		JTextArea textArea = new JTextArea();
		//Setting the JTextArea to hold all books sorted by price for the user
		try {
		    ArrayList<book> bookList = viewBookList();
		    StringBuilder sb = new StringBuilder();

		    
	    	
    		for (book book : bookList) {
    		
		        sb.append("Title: ").append(book.getTitle()).append("\n");
		        sb.append("Barcode: ").append(book.getBarcode()).append("\n");
		        sb.append("Genre: ").append(book.getGenre()).append("\n");
		        sb.append("Price: £").append(book.getRetailPrice()).append("\n");
		        sb.append("Quantity: ").append(book.getQuantity()).append("\n");
		        sb.append("Language: ").append(book.getLanguage()).append("\n");
		        sb.append("Type: ").append(book.getType()).append("\n");
		        if (book.getType().equals("paperback")) {
		        	paperback paperback = (paperback) book;
			        sb.append("Condition: ").append(paperback.getCondition()).append("\n");
			        sb.append("Pages: ").append(paperback.getPageCount()).append("\n");
			        sb.append("\n");
    			}
    	
    			if (book.getType().equals("audiobook")) {
    				audiobook audiobook = (audiobook) book;
			        sb.append("Format: ").append(audiobook.getFormat()).append("\n");
			        sb.append("Length: ").append(audiobook.getListeningLength()).append("\n");
			        sb.append("\n");
    			}
    			
			    if (book.getType().equals("ebook")) {
			    	ebook ebook = (ebook) book;
			        sb.append("Format: ").append(ebook.getFormat()).append("\n");
			        sb.append("Pages: ").append(ebook.getPageCount()).append("\n");
			        sb.append("\n");
				  }
    		}
		    
		    textArea.setText(sb.toString());
		} catch (IOException e) {
		    // Handle the exception appropriately
		}
		scrollPane.setViewportView(textArea);
		
		JLabel lblNewLabel_2 = new JLabel("All Books:");
		lblNewLabel_2.setBounds(77, 11, 160, 14);
		books_panel.add(lblNewLabel_2);
		
		txtCreds = new JTextField();
		txtCreds.setEditable(false);
		txtCreds.setForeground(new Color(0, 0, 0));
		txtCreds.setHorizontalAlignment(SwingConstants.CENTER);
		
		
		// Credit set to logged in user's credit balance initially 
		if(loggedInUser == "user2") {
			double credit = user2.getCredit();
			String credStr = String.valueOf(credit);
			JLabel credit_label = new JLabel(credStr);
			credit_label.setBounds(186, 36, 48, 14);
			home_panel.add(credit_label);
			System.out.print(credStr);
			txtCreds.setText("£"+credStr);
		}
		if(loggedInUser == "user3") {
			double credit = user3.getCredit();
			String credStr = String.valueOf(credit);
			JLabel credit_label = new JLabel(credStr);
			credit_label.setBounds(186, 36, 48, 14);
			home_panel.add(credit_label);
			System.out.print(credStr);
			txtCreds.setText("£"+credStr);
		}
		if(loggedInUser == "user4") {
			double credit = user4.getCredit();
			String credStr = String.valueOf(credit);
			JLabel credit_label = new JLabel(credStr);
			credit_label.setBounds(186, 36, 48, 14);
			home_panel.add(credit_label);
			System.out.print(credStr);
			txtCreds.setText("£"+credStr);
		}
		
		txtCreds.setBounds(441, 68, 172, 50);
		basket_panel.add(txtCreds);
		txtCreds.setColumns(10);
		
		JButton checkout_button = new JButton("Finish and Pay");
		checkout_button.setBounds(441, 260, 172, 23);
		checkout_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double newCredit;
				double credit;
				if(loggedInUser == "user2") {
					credit = user2.getCredit(); // Gets current credit of user
					double total = basket.getTotal(); // Finds price of basket
					
					if(credit >= total) {
						txtTotal.setText("£0"); // Clears the basket and removes the owed balance
						newCredit = credit-total;
						txtCreds.setText("£"+String.valueOf(newCredit)); // Updates the credits
						basket.cancelBasket();
						basketarea.setText("");
						/*ArrayList<Integer> barcodelist = basket.getBarcodes();
						for(Integer barcode : barcodelist) {
							try {
								book.updateQuantity(barcode);
							} catch (IOException e1) {
								e1.printStackTrace();
							}
						}*/
						// above code I tried to implement updating quantity
					
						//Receipt
						JOptionPane.showMessageDialog(null, "Thank you for the purchase! £"+String.valueOf(total)+" paid and your remaining credit balance is £"+String.valueOf(newCredit)+". Your delivery address is "+user2.getAddress()+".", "Receipt", JOptionPane.PLAIN_MESSAGE);
						
						try {
							user2.updateCredit(credit, newCredit);
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}else {
						JOptionPane.showMessageDialog(null, "Not enough credits!", "Error", JOptionPane.ERROR_MESSAGE); //Error if insufficient credits
					}
				}
				if(loggedInUser == "user3") {
					credit = user3.getCredit();
					double total = basket.getTotal();
					
					if(credit >= total) {
						txtTotal.setText("£0");
						newCredit = credit-total;
						txtCreds.setText("£"+String.valueOf(newCredit));
						basket.cancelBasket();
						basketarea.setText("");
						JOptionPane.showMessageDialog(null, "Thank you for the purchase! £"+String.valueOf(total)+" paid and your remaining credit balance is £"+String.valueOf(newCredit)+". Your delivery address is "+user3.getAddress()+".", "Receipt", JOptionPane.PLAIN_MESSAGE);
						
						try {
							user3.updateCredit(credit, newCredit);
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}else {
						JOptionPane.showMessageDialog(null, "Not enough credits!", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}
				if(loggedInUser == "user4") {
					credit = user4.getCredit();
					double total = basket.getTotal();
					
					if(credit >= total) {
						txtTotal.setText("£0");
						newCredit = credit-total;
						txtCreds.setText("£"+String.valueOf(newCredit));
						basket.cancelBasket();
						basketarea.setText("");
						JOptionPane.showMessageDialog(null, "Thank you for the purchase! £"+String.valueOf(total)+" paid and your remaining credit balance is £"+String.valueOf(newCredit)+". Your delivery address is "+user4.getAddress()+".", "Receipt", JOptionPane.PLAIN_MESSAGE);
						
						try {
							user4.updateCredit(credit, newCredit);
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}else {
						JOptionPane.showMessageDialog(null, "Not enough credits!", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});
		basket_panel.setLayout(null);
		basket_panel.add(checkout_button);
		
		JLabel lblNewLabel_5 = new JLabel("Basket Items:");
		lblNewLabel_5.setBounds(64, 11, 413, 30);
		lblNewLabel_5.setFont(new Font("Dialog", Font.BOLD, 12));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.LEFT);
		basket_panel.add(lblNewLabel_5);
		
		
		//Cancel purchase wipes the basket and basketarea text and total price.
		JButton btnNewButton = new JButton("Cancel Purchase");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
			        System.out.print(loggedInUser);
					
					if(loggedInUser == "user2") {
						basket.cancelBasket();
						basketarea.setText("");
						txtTotal.setText("£0");
						System.out.print(basket.displayBasketItems());
					}
					if(loggedInUser == "user3") {
						basket.cancelBasket();
						basketarea.setText("");
						txtTotal.setText("£0");
						System.out.print(basket.displayBasketItems());
					}
					if(loggedInUser == "user4") {
						basket.cancelBasket();
						basketarea.setText("");
						txtTotal.setText("£0");
						System.out.print(basket.displayBasketItems());
					}		
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(107, 314, 181, 23);
		basket_panel.add(btnNewButton);
		
		JLabel credits = new JLabel("Your Credits:");
		credits.setBounds(501, 43, 112, 14);
		credits.setFont(new Font("Tahoma", Font.BOLD, 11));
		credits.setHorizontalAlignment(SwingConstants.RIGHT);
		basket_panel.add(credits);
		
		// sign out returns you to log in frame
		JButton signout = new JButton("Sign Out");
		signout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loginFrame loginFrame = new loginFrame();
				loginFrame.setVisible(true);
				dispose();
			}
		});
		signout.setBounds(587, 13, 118, 23);
		customer_pane.add(signout);
		
		JLabel title = new JLabel("Bookshop");
		title.setFont(new Font("Tahoma", Font.PLAIN, 16));
		title.setBounds(318, 11, 108, 23);
		customer_pane.add(title);
	}
	// view all books from the text file
	// ArrayList of books is produced each book of type paperback, audiobook or ebook
	public static ArrayList<book> viewBookList() throws IOException{
		// Create a StringBuilder to build the output string
	    
	    ArrayList<book> list = new ArrayList<book>();
	    File inputFile = new File("Stock.txt");
		Scanner fileScanner = new Scanner(inputFile);
		while (fileScanner.hasNextLine()) {
			String[] bookDetails = fileScanner.nextLine().split(",") ;
			if((bookDetails[1].trim()).equals("paperback")) {
				list.add(new paperback(Integer.parseInt(bookDetails[0].trim()),(bookDetails[1].trim()),
						(bookDetails[2].trim()),(bookDetails[3].trim()),(bookDetails[4].trim()),
						(bookDetails[5].trim()),Integer.parseInt(bookDetails[6].trim()),
						Double.parseDouble(bookDetails[7].trim()),Double.parseDouble(bookDetails[8].trim()),
						(bookDetails[9].trim())));
			}
			if((bookDetails[1].trim()).equals("audiobook")) {
				list.add(new audiobook(Integer.parseInt(bookDetails[0].trim()),(bookDetails[1].trim()),
						(bookDetails[2].trim()),(bookDetails[3].trim()),(bookDetails[4].trim()),
						(bookDetails[5].trim()),Integer.parseInt(bookDetails[6].trim()),
						Double.parseDouble(bookDetails[7].trim()),Double.parseDouble(bookDetails[8].trim()),
						(bookDetails[9].trim())));
			}
			if((bookDetails[1].trim()).equals("ebook")) {
				list.add(new ebook(Integer.parseInt(bookDetails[0].trim()),(bookDetails[1].trim()),
						(bookDetails[2].trim()),(bookDetails[3].trim()),(bookDetails[4].trim()),
						(bookDetails[5].trim()),Integer.parseInt(bookDetails[6].trim()),
						Double.parseDouble(bookDetails[7].trim()),Double.parseDouble(bookDetails[8].trim()),
						(bookDetails[9].trim())));
			}
		}
		fileScanner.close();
		// Sorted by price for customer
	    Collections.sort(list, Comparator.comparing(book :: getRetailPrice));
		return list;
	}
}
