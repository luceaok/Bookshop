import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class loginFrame extends JFrame {

	public static JComboBox userDropdown;
	private JPanel contentPane;
	private String loggedIn = "";


	/**
	 * Launch the application.
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					loginFrame frame = new loginFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public loginFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 418, 243);
		contentPane.add(panel);
		panel.setLayout(null);
		
		//comboBox that allows user to choose an account to log into
		JComboBox userDropdown = new JComboBox();
		userDropdown.setModel(new DefaultComboBoxModel(new String[] {"user1", "user2", "user3", "user4"})); 
		userDropdown.setBounds(99, 78, 214, 22);
		panel.add(userDropdown);
		
		JLabel selectUserLabel = new JLabel("Select User:");
		selectUserLabel.setBounds(162, 53, 89, 14);
		panel.add(selectUserLabel);
		
		JButton loginButton = new JButton("Login");
		loginButton.setBounds(162, 131, 89, 23);
		panel.add(loginButton);
		
		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if((userDropdown.getSelectedItem()).equals("user1")) {
					//since user 1 is an admin we open the admin window
					adminFrame adminFrame;
					
					String selectedUser = userDropdown.getSelectedItem().toString();
	                loggedIn = selectedUser;	
				
					try {
						adminFrame = new adminFrame();
						adminFrame.setVisible(true);
						dispose();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}else{
					//since all other users are customers, if its not user 1 we open the customer window
					customerFrame customerFrame;
					String selectedUser = userDropdown.getSelectedItem().toString();
	                loggedIn = selectedUser;	
				
					try {
						customerFrame = new customerFrame(loggedIn); //the logged on user is parsed to the customer frame
					
						customerFrame.setVisible(true);
						dispose();
						
					
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
						 
					
				}
			}
		});
		
	}
	
	// Getter method for loggedIn
    public String getLoggedIn() {
        return loggedIn;
    }
}
