import java.io.IOException;

public abstract class user{
	public int userId;
	public String username;
	public String surname;
	public int houseNo;
	public String postcode;
	public String city;
	public String userType;
	
	// Constructor
	public user(int userId, String username, String surname, int houseNo, String postcode, String city,
			String userType) {
		this.userId = userId;
        this.username = username;
        this.surname = surname;
        this.houseNo = houseNo;
        this.postcode = postcode;
        this.city = city;
        this.userType = userType;
	}

	public static void main(String[] args) throws IOException{
	}

	public String toString() {
		return null;
	}
	
	
	
}
