//Enum for audiobook format
public enum audioFormat {
	MP3, 
	WMA, 
	AAC
}
