import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class basket {
    private ArrayList<book> basketItems;
    
    // Constructor
    public basket() {
        basketItems = new ArrayList<>();
    }

    // addToBasket is a method that uses the find method to locate the barcode in the text file and parse all related book info
    // in order to create a new object book to add to ArrayList bookItems
    public void addToBasket(int barcode) {
        String line = find(barcode);
        String[] parts = line.split(",");
        if ((parts[1].trim()).equals("paperback")) { // check the type of book to ensure the correct attributes are added
        	book book = new paperback(
        			Integer.parseInt(parts[0]),
        			parts[1].trim(),
        			parts[2].trim(),
        			parts[3].trim(),
        			parts[4].trim(),
        			parts[5].trim(),
        			Integer.parseInt(parts[6].trim()),
        			Double.parseDouble(parts[7].trim()),
        			Double.parseDouble(parts[8].trim()),
        			parts[9].trim());
        	basketItems.add(book);
        	System.out.println(book.getTitle() + " added to the basket.");
        }
        if ((parts[1].trim()).equals("audiobook")) {
        	book book = new audiobook(Integer.parseInt(parts[0].trim()),
        			parts[1].trim(),
        			parts[2].trim(),
        			parts[3].trim(),
        			parts[4].trim(),
        			parts[5].trim(),
        			Integer.parseInt(parts[6].trim()),
        			Double.parseDouble(parts[7].trim()),
        			Double.parseDouble(parts[8].trim()),
        			parts[9].trim());
        	basketItems.add(book);
        	System.out.println(book.getTitle() + " added to the basket.");
        	}
        if ((parts[1].trim()).equals("ebook")) {
        	book book = new ebook(Integer.parseInt(parts[0].trim()),
        			parts[1].trim(),
        			parts[2].trim(),
        			parts[3].trim(),
        			parts[4].trim(),
        			parts[5].trim(),
        			Integer.parseInt(parts[6].trim()),
        			Double.parseDouble(parts[7].trim()),
        			Double.parseDouble(parts[8].trim()),
        			parts[9].trim());
        	basketItems.add(book);
        	System.out.println(book.getTitle() + " added to the basket.");
        	}
    }

    // Cancelling the basket clears all items from the ArrayList 
    public void cancelBasket() {
        basketItems.clear();
        System.out.println("Basket cleared.");
    }
    
    // Getting the total produces a sum of all the prices of the books that are in the basket
    public double getTotal(){
    	ArrayList<book> basketList = new ArrayList<>();
    	double total = 0;
        for (book book : basketItems) {
        	basketList.add(book);
        }
        for (book book : basketList) {
		    total = total + (book.getRetailPrice());
        }
		return total;
    }
    
    // creates an arraylist of all the barcodes of the books in the basket
    // needed to update the quantity of the books in the text file after purchase
    public ArrayList<Integer> getBarcodes(){
    	ArrayList<Integer> barcodeList = new ArrayList<>();
        for (book book : basketItems) {
        	barcodeList.add(book.getBarcode());
        }
		return barcodeList;
    }
    
    
    
    // Returns a StringBulder of all the items in the basket broken up into their respective attributes
    public StringBuilder displayBasketItems() throws IOException {
        System.out.println("Books in the basket:");
        ArrayList<book> basketList = new ArrayList<>();
        for (book book : basketItems) { // iterates through the basket items and appends each book to bookList
        	basketList.add(book);
        }
        ArrayList<book> bookList = basketList;
		StringBuilder basketStr = new StringBuilder();
		
		
		for (book book : bookList) { // iterates through the basket items and appends to the StringBuilder
		
		    basketStr.append("Title: ").append(book.getTitle()).append("\n");
		    basketStr.append("Barcode: ").append(book.getBarcode()).append("\n");
		    basketStr.append("Genre: ").append(book.getGenre()).append("\n");
		    basketStr.append("Price: £").append(book.getRetailPrice()).append("\n");
		    basketStr.append("Quantity: ").append(book.getQuantity()).append("\n");
		    basketStr.append("Language: ").append(book.getLanguage()).append("\n");
		    basketStr.append("Type: ").append(book.getType()).append("\n");
		    if (book.getType().equals("paperback")) {
		    	paperback paperback = (paperback) book;
		        basketStr.append("Condition: ").append(paperback.getCondition()).append("\n");
		        basketStr.append("Pages: ").append(paperback.getPageCount()).append("\n");
		        basketStr.append("\n");
			}
  	
			if (book.getType().equals("audiobook")) {
				audiobook audiobook = (audiobook) book;
		        basketStr.append("Format: ").append(audiobook.getFormat()).append("\n");
		        basketStr.append("Length: ").append(audiobook.getListeningLength()).append("\n");
		        basketStr.append("\n");
			}
			
		    if (book.getType().equals("ebook")) {
		    	ebook ebook = (ebook) book;
		        basketStr.append("Format: ").append(ebook.getFormat()).append("\n");
		        basketStr.append("Pages: ").append(ebook.getPageCount()).append("\n");
		        basketStr.append("\n");
			  }
		}
		
		return basketStr;
        
    }
    
    
    // Finds the barcode in the Stock text file
    // If there returns the entire line (all the book attributes)
    public static String find(int i) {
        int targetBarcode = i;
        boolean barcodeFound = false;
        String foundLine = null;

        try (BufferedReader br = new BufferedReader(new FileReader("Stock.txt"))) {
            String line;
            barcodeFound = false;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");

                for (String part : parts) {
                    int barcode;
                    try {
                        barcode = Integer.parseInt(part.trim());
                    } catch (NumberFormatException e) {
                        continue;
                    }

                    if (barcode == targetBarcode) {
                        barcodeFound = true;
                        foundLine = line;
                        break;
                    }
                }

                if (barcodeFound) {
                    break;
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
		return foundLine;
    }
    


    public static void main(String[] args) throws IOException {
    }
}