import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public abstract class book {
	protected int barcode;
	protected String type;
	protected String title;
	protected String language;
	protected String genre;
	protected String releaseDate;
	protected int stockQuantity;
	protected double retailPrice;
	
	//constructor	
	public book(int barcode, String type, String title, String language, String genre, String releaseDate, int stockQuantity,
			double retailPrice) {
		this.barcode = barcode;
		this.type = type;
		this.title = title;
		this.language = language;
		this.genre = genre;
		this.releaseDate = releaseDate;
		this.stockQuantity = stockQuantity;
		this.retailPrice = retailPrice;
	}
	
	// getter and setter methods
	
	public int getBarcode() {
		return barcode;
	}
	
	public int getQuantity() {
		return stockQuantity;
	}

	public String getTitle() {
		return title;
	}
	
	public String getType() {
		return type;
	}
	public String getGenre() {
		return genre;
	}
	
	public String getLanguage() {
		return language;
	}
	
	public Double getRetailPrice() {
		return retailPrice;
	}
	
	//function that is suposed to update the quantity of book in file if purchased by searching for the book using the barcode
	public static void updateQuantity(int barcode) throws IOException {
    	File inputFile = new File("Stock.txt");
    	Scanner fileScanner = new Scanner(inputFile);
    	int rowIndex = 0;
    	
    	while(fileScanner.hasNextLine()) {
    		String line = fileScanner.nextLine();
    		String[] parts = line.split(",");
    		if(parts[0].trim().equals(String.valueOf(barcode))) {
    			break;
    		}else {
    			rowIndex++;
    		}
    	}
    	fileScanner.close();
    	
    	Path path = Paths.get("Stock.txt");
    	List<String> rows = Files.readAllLines(path, StandardCharsets.UTF_8);
    	
    	String lineToUpdate = rows.get(rowIndex);
    	String[] parts = lineToUpdate.split(",");
    	
    	if(parts[0].trim().equals(String.valueOf(barcode))) {
    		double oldQuant = Double.parseDouble(parts[6].trim());
    		double newQuant = oldQuant - 1;
    		parts[6] = " "+String.valueOf(newQuant);
    		
    		String updatedLine = String.join(",", parts);
    		rows.set(rowIndex, updatedLine);
    		
    		Files.write(path, rows, StandardCharsets.UTF_8);
    	}
    }
	
}



